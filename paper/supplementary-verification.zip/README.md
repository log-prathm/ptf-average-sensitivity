# Supplementary Material S1

Supplementary verification for *An elementary improvement of the average sensitivity bound for polynomial threshold functions*, by Prathmesh Lagdive, Vaibhav Aglave, and Suraj Damre.

The universal theorem is proved analytically in the accompanying manuscript. The checks here verify finite instances and constants; the numerical experiments do not establish optimality or replace the proof.

## Exact checks

```bash
python3 verify_127.py
```

Python 3 and its standard library are sufficient. The script writes `127-exact-verification.json` beside itself and checks:

- The positive rational certificate for the uniform coefficient 383/100.
- Binomial-deviation identities and the central-binomial induction inequality.
- 14,584 nontrivial dimension-degree pairs and 1,986,416 trivial-branch pairs through dimension 2000.
- 3,240 rational interval inequalities used in the coupling lemma.

## Optional numerical checks

```bash
python3 -m venv .venv
.venv/bin/pip install -r requirements-optional.txt
.venv/bin/python explore_127.py
```

The recorded run used Python with NumPy 2.3.2, SciPy 1.16.1, and random seed 127. It includes eight coupling linear programs and 63 weighted-grading examples. The previously recorded output is `127-numerical-checks.json`.

The LP and matrix outputs are floating-point exploration. No result in the analytic proof assumes a floating-point optimum.

## License and attribution

The verification scripts and accompanying supplementary documentation and recorded outputs are provided under Apache License 2.0; see `LICENSE-APACHE-2.0`. The manuscript is separately offered under CC BY 4.0. The weighted-grading construction and edge-recovery argument are due to the OpenAI family-127 manuscript cited in the paper. Codex assisted with the refinement and these scripts.
